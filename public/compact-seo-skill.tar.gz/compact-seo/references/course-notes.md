# Compact Keywords Course Notes — From Transcripts
## Edward Sturm | Compiled March 25, 2026

---

## PART 1: Foundations

### The Funnel (Core Concept)
- **Top of Funnel (TOFU):** "What is a CRM?" → exploratory, zero purchase intent, low conversion
- **Middle of Funnel (MOFU):** "Best home workout equipment" → comparing, tentative, maybe
- **Bottom of Funnel (BOFU):** "CRM with call forwarding and routing" → KNOWS what they want, doesn't know the brand

### Properties of Compact Keywords
1. **Low competition** — few people target them (fooled by low search volume)
2. **~415 words per page** — can be as low as 200 words
3. **Templatizable** — reuse sections across pages
4. **Low authority needed** — sites with DA under 10 can rank #1
5. **Lower search volumes** — BUT rank for 1 compact keyword = rank for many related ones
6. **Way higher converting** — 5-15% vs 0.5-2% for TOFU
7. **Durable** — untouched by Google updates for YEARS
8. **AI-resistant** — chatbots RECOMMEND BOFU pages (pattern matching)

### Why TOFU is Dead
- Google March update obliterated content sites (50-95% traffic loss)
- Reddit/Quora taking TOFU rankings
- AI chatbots answering TOFU questions directly
- Skyscraper technique (2,000-3,000 word articles) = waste of time now
- algoroo.com shows unprecedented SERP volatility

### Key Examples
- **SociableKit** (DA 23) outranks Indeed for "embed indeed jobs on website"
- **Stagetimer.io** — $10K MRR, ~30 DA, all BOFU keywords, programmatic SEO
- **Coloring pages site** — DA 18 (was 8 when first ranking), 1,200+ keywords, AI-generated images
- **Edward's own comparison:** BOFU site (not updated in year, lower DA) = stable traffic going UP. TOFU site (updated regularly, higher DA) = volatile, trending DOWN.

### Who Can Use Compact Keywords
- Website owners (even low DA)
- Creators on YouTube, TikTok, Instagram, LinkedIn, Pinterest
- Amazon/marketplace sellers
- Reddit posters
- App store listings
- Anyone with a brand solving a problem

### YouTube Shorts Insight
- Ranked #1 with featured snippet 8 HOURS after posting a short
- YouTube prioritizes shorts for search answers now
- Creator got 100K views + 400 subscribers from ONE short, 85% from search

---

## PART 2: Getting Technical

### SEO Browser Extensions
- **MozBar** is Edward's choice (also: detailed.com, Ahrefs, SEMrush extensions)
- Shows: Page Authority, Domain Authority, links, root domains
- Critical fields to check: URL, Page Title, Meta Description, H1, Alt Text
- **Pro tip:** Keep DA visible next to URL bar at all times — useful for spotting scams, checking legitimacy
- **HTTP status tab** — see redirects (301s), useful for affiliate URL debugging

### When to Target vs Skip a Keyword
- Look at DA of sites currently ranking in SERPs
- If DA 80-90+ with well-optimized pages → SKIP (too competitive)
- If DA in teens/20s/30s with poorly optimized pages → GO FOR IT
- Don't rely on "difficulty" scores from tools — look at actual SERP DAs
- Check on-page optimization scores of competitors (Moz On-Page Grader)

### Google Search Console Setup
1. Connect site (domain property + all HTTPS/subdomain variations)
2. Submit sitemaps (post sitemap + page sitemap)
3. Make sure sitemap is in robots.txt
4. Submit new/updated pages via "Inspect any URL" → Request indexing
5. **Also connect to Bing Webmaster Tools** — improves Bing rankings AND ChatGPT/SearchGPT recommendations

### Site Audit with Screaming Frog
- Free version: crawl up to 500 URLs
- Filter: HTML only → Status 200 → Indexable only
- Check for:
  - 404 errors (fix broken pages)
  - Missing page titles
  - Missing/bad meta descriptions
  - Missing H1s or duplicate H1s (BAD)
  - Nonsensical URL slugs (random characters = fix)
  - Lorem Ipsum left in (search: site:yourdomain.com lorem ipsum)
  - Junk/thin pages being indexed (noindex them)
- If pages don't show in crawl → probably need server-side rendering

### Site Audit Template (Edward's Template)
- Export Screaming Frog data → paste into template
- Columns: URL, Page Title, Meta Description, H1, H2s, Word Count, Crawl Depth, In-links
- Blue columns = where you write new/improved versions
- For deleted pages → 301 redirect to new URL
- For changed URL slugs → 301 redirect to new slug
- Write concise purpose for each page (find junk pages)
- Page title pattern: "Keyword Title | Brand Name" (with vertical divider)
- Meta description: 120-158 characters
- After changes → submit to Google Search Console → mark as done

### Page Speed Best Practices
- Use CDN (Cloudflare recommended)
- Compress images (TinyPNG)
- Use WebP format
- Responsive image generation (different sizes for different devices)
- Lazy loading — DANGEROUS if implemented wrong (Google can't crawl lazy-loaded content)
- **PageSpeed Insights is OVERRATED** — test yourself, ask people in different locations
  - Leeway Hertz: failed Core Web Vitals, 77/100 mobile, still has great rankings
  - If it FEELS fast to users, you're fine regardless of score

### Programmatic SEO
- Create template pages → swap out specific terms from database
- Example: Zapier integration pages ("Connect Google Sheets to MailerLite")
- Same page structure, different data populated per keyword
- Works with low DA (coloring pages site: DA 13, ranking for tons of keywords)
- Mark Lu has a guide on programmatic SEO setup

### Follow vs NoFollow Links
- Follow links pass SEO "link juice" (authority)
- NoFollow links don't pass juice but still valuable
- Google cares less about this distinction now
- Use NoFollow on affiliate links (ToS compliance)
- Want a MIX of high DA, mid DA, and low DA backlinks (avoid looking spammy)

---

## KEY TAKEAWAYS FOR MOZ TRIAL

### Pre-Trial Checklist
1. ✅ Have seed keyword lists ready for both products
2. ✅ Know competitor domains to analyze
3. Use MozBar extension during trial for SERP analysis
4. Use Moz On-Page Grader to score competitor pages
5. Use Moz Keyword Explorer for volume + DA of ranking sites
6. Export everything to spreadsheets before trial ends

### What to Look for in Moz
- Keywords where SERP DAs are under 30-40
- Keywords where competitors have low on-page optimization scores
- Keywords with purchase/use intent (BOFU, not TOFU)
- "No data available" volume = GOOD (means nobody's competing)
- Check: does ranking for 1 compact keyword pull in related keywords?

### Applied to Reviewly
- Target: "AI review response generator for [business type]"
- Each page: ~415 words, keyword in title/meta/URL/H1/first sentence
- Reuse sections across pages (pricing, CTA, how it works)
- Don't write 2,000 word blog posts — short, focused landing pages

### Applied to ClaimArmor Pivot
- Target: "AI move out inspection report", "tenant damage report generator"
- Programmatic potential: generate pages for each state's security deposit laws
- E.g., "security deposit documentation tool [state]" × 50 states = 50 pages

---

## PART 3: On-Page SEO & Landing Page Template

### Moz On-Page Grader — The Secret Weapon
- Access via MozBar (Page Optimization icon) or Moz website
- Put in your URL + target keyword → shows everything to fix
- **Target score: 96-98** (sweet spot)
- 100 = over-optimization, Google may penalize
- Edward de-optimized from 100→98 (removed keyword from alt text) and ranked BETTER
- Can only check once per day — make changes, wait 24hrs, recheck

### How to Assess SERP Competitiveness (Edward's Method)
- DON'T trust difficulty scores from tools
- Instead: search the keyword → look at page optimization scores in MozBar SERP analysis
- If all competitors have LOW page scores (poorly optimized) = wide open opportunity
- If competitors have HIGH DA + HIGH page scores = too competitive, skip
- Example: "voice recording for lawyers" — nobody optimized for it, all page scores terrible → could rank #1 in first week

### The Ranking Timeline for Non-Competitive Keywords
1. Publish optimized page
2. Submit to Google Search Console
3. First week/month: land on page 1
4. If searchers click and DON'T bounce → Google ranks you higher
5. Naturally climbs to #1 over weeks/months
6. Stays #1 for YEARS without updates

### Bottom-of-Funnel SEO Landing Page Template

**Document Structure:**
```
Title: Template — [Primary Keyword], [Keyword 2], [Keyword 3]
URL: /uses/[keyword-slug]
Page Title: [Primary Keyword] | [Brand Name]
Meta Description: [120-158 chars, keyword near beginning]
H1: [Primary Keyword — exact match]

First sentence: Use keyword near the beginning
  → 2-3 short, punchy sentences
  → [CTA Button: "Try Free" / "Get Started" / "Contact Us"]

H2: [Section Title — use keyword variation if natural]
  → Short paragraphs (1-3 sentences, usually 1)
  → Bullet points for extra context
  → [repeat for 3-5 sections]

[CTA Button again at bottom — same as top]
```

**Writing style:**
- Short and punchy sentences
- Paragraphs = 1-3 sentences (usually 1)
- Heavy use of bullet points
- NOT 2,000 word blog posts — these are ~415 word focused landing pages
- Write copy in template doc FIRST → then move to CMS with images

**Keyword targeting per page:**
- 1 primary keyword (the focus)
- 1-2 secondary keywords (bonus rankings)
- MAX 3 keywords per page — don't over-target
- Ranking #1 for primary pulls in related keywords automatically

### Information Architecture Patterns
- `/uses/[use-case]` — each use case gets its own page (Reverb, Bitrix24)
- `/services/[service]` — each service gets its own page
- `/alternatives/[competitor]` — control the narrative on competitor comparisons
- `/[topic]-for-[audience]` — audience-specific landing pages
- Keep URL structure rational, logical, predictable

### After Publishing
1. Write copy in template doc
2. Move to CMS, add images
3. Check with Moz On-Page Grader (aim 96-98)
4. Fix any issues Moz identifies
5. Wait 24hrs, recheck score
6. Submit to Google Search Console (Inspect URL → Request Indexing)
7. Monitor ranking over coming weeks

---

## PART 4: On-Page SEO Deep Dive — Building BOFU Landing Pages

### The Exact On-Page Optimization Checklist
1. **Keyword in URL:** `/uses/voice-recording-for-students`
2. **Keyword at beginning of page title:** "Voice Recording for Students | Reverb Record"
3. **Keyword in meta description** (near the beginning)
4. **Keyword as H1** (exact match or natural variation)
5. **Keyword at beginning of first sentence**
6. **Keyword in alt text** of first image (optional but recommended)
7. **Target Moz On-Page Score: 97-98**

### Page Title Formula
```
[Keyword] | [Brand Name]
```
- Use vertical divider `|` — learned at enterprise level, looks professional
- Brand name always at the end
- Set up auto in CMS (Yoast does this automatically)

**Advanced: Add CTA or benefit to page title:**
```
Voice Recording for Students | Free, No Signup | Reverb Record
```
- OK if title gets cut off in Google — as long as the CTA/benefit is visible
- Test with SERP preview tools before publishing

### Page Structure (The Template)
```
[H1: Primary Keyword]

[2-3 punchy intro sentences — keyword near beginning of first sentence]

[CTA Button: "Try Free" / "Get Started" / etc.]

[Hero image — BELOW CTA button on mobile]

[H2: Section Title]
[1-3 sentences + bullet points]
[Image on right]
--- dividing line ---

[H2: Section Title]
[1-3 sentences + bullet points]
[Image on left]
--- dividing line ---

[H2: Section Title]
[1-3 sentences + bullet points]
[Image on right]
--- dividing line ---

[CTA Button again — same destination as top CTA]
```

### Key Writing Rules
- **Neutral tone** — converts better AND more likely to be picked up by AI chatbots
- **NO sensationalism** — avoid "deadly", "ruins", "war zone", "crazy"
- **NO superlatives** — avoid "best", "greatest", "#1"
- **OK to emphasize** — "free", "instant", "no signup required", "perfect for [audience]"
- **Short paragraphs** — 1-3 sentences, typically just 1
- **Heavy bullet points** — list use cases, features, context
- **~415 words total** (400-500 range) — Edward's own pages are 472 words
- **Don't use AI to generate copy** — Edward doesn't (personal choice, risk avoidance). But if you do, have a human proofread who knows the brand intimately

### Section Layout Pattern
- Alternate: image right → image left → image right
- Use dividing lines between sections
- If no appropriate image for a section, center text (no image is OK)
- Reuse images across multiple BOFU pages (same product screenshots)
- Reuse entire sections across pages (FAQ, pricing, engagement models, etc.)

### Reusable Sections Strategy (Key Insight)
- **80% unique content NEAR THE TOP** of the page
- Reusable sections (FAQ, pricing, CTA, trust logos) go BELOW
- Visitor must see unique/relevant content FIRST or they bounce
- Spread some unique content throughout page (looks authentic)
- Tag-based system: if page has tag X, section Y auto-populates

### Handling Awkward Keywords
- If keyword is clunky ("students record themselves reading"), make it natural
- H1/title: "Have Your Students Record Themselves Reading" (added "Have Your")
- URL slug can still be the exact keyword: `/uses/students-record-themselves-reading`
- Moz score may drop slightly — that's fine, authenticity > score
- Google detects and penalizes unnatural/clunky titles

### What This Means for Reviewly's SEO Pages

**Page template for each business type:**
```
URL: /for/restaurants
Title: AI Review Response Generator for Restaurants | Reviewly
Meta: Generate professional responses to restaurant Google reviews in 10 seconds. Free to try, no signup required.
H1: AI Review Response Generator for Restaurants

"Responding to Google reviews for your restaurant is [keyword near start].
Reviewly generates personalized, professional responses that reference 
specific details from each review — in 10 seconds, not 15 minutes."

[CTA: Try Free — 5 Responses/Month]

[Demo screenshot showing restaurant review + generated response]

H2: Why Restaurant Reviews Matter
[2-3 sentences + bullet points about Google ranking, customer trust]

H2: How Reviewly Works for Restaurants
[3 bullet points: paste → generate → copy]

H2: What Makes Our Responses Different
[bullet points: references specific dishes, wait times, server names, etc.]

[Reusable: Pricing section]
[Reusable: FAQ section]
[CTA: Get Started Free]
```

**Pages to create:**
- /for/restaurants
- /for/dentists  
- /for/salons
- /for/hotels
- /for/auto-repair
- /for/medical-practices
- /for/property-managers
- /for/veterinarians

Each page: ~415 words, unique intro + a few unique sections, shared FAQ/pricing/CTA at bottom.

---

## PART 5: Legitimacy, Image SEO & Information Architecture

### Making Your Site Look Legitimate (Reduces Need for Backlinks)
Trust signals that help you rank with LESS domain authority:

1. **Terms of Service + Privacy Policy** — link in footer
2. **Contact page** — with at least email (phone optional)
3. **NAP (Name, Address, Phone)** — consistent across ALL directories
4. **Social media profiles** — link in footer
5. **Short blog** — write a few articles YOURSELF (not AI). Afternoon's work. Link out to other sites from blog posts (confirmed by experiments to improve rankings)
6. **Consistent branding** — same look/feel across all pages
7. **Wide margins, white space** — Apple, Louis Vuitton, Tesla approach. Clean = trust. Cluttered = bounce.

### Link-Out Experiment (Key Finding)
- 10 domains tested, same content, same keyword
- 5 linked out to external sites, 5 didn't
- **Sites that linked OUT ranked significantly HIGHER**
- Don't be afraid to link out to high-authority sites (especially from blog posts)

### Google API Leak Confirmation
- Google DOES use Chrome data to measure user engagement
- **Original Content Score** — less content on page = more original it needs to be
- Confirms: BOFU landing pages with reusable sections MUST have unique content that's highly relevant to the keyword, especially near the top
- Don't use AI-generated text for blog posts (risk of penalty)

### Image SEO Best Practices
1. **File naming structure:** `[subfolder]_[page-slug]_[image-description].webp`
   - Example: `uses_voice-recording-for-students_recording-share-links.webp`
2. **Alt text:** First image = keyword. Other images = descriptive, relevant to page content
3. **Reused images across pages:** Re-upload with UNIQUE file name + alt text per page
4. **Hero image:** Can be same image across BOFU pages, but upload separately with unique alt text each time
5. **File size:** Use WebP format. Compress with TinyPNG.
6. **DON'T over-optimize:** Only put keyword in alt text of FIRST image

### Information Architecture — The Hub Page System

**Core Principle:** Pages you want to rank should be 2-3 clicks from homepage. NEVER orphan pages.

**Crawl depth matters:**
- 0 clicks = homepage (most important)
- 1 click = very important
- 2 clicks = ideal for BOFU landing pages
- 3 clicks = acceptable
- 4+ clicks = risky, Google sees as low importance

**Hub page types:**
| Type | URL | Best For |
|------|-----|----------|
| Uses | /uses/ | Product companies (SaaS, tools) |
| Services | /services/ | Services businesses |
| Alternatives | /alternatives/ | Competitor comparison pages |
| Solutions | /solutions/ | General (works for most) |
| Software | /software/ | Affiliate sites |

**Hub page structure:**
```
H1: [Hub Title] — e.g., "Uses" or "Solutions"
Intro text: 1-2 sentences about the hub
Categories (H2s): Group pages by type
  → Links to individual BOFU landing pages (H1 as anchor text)
CTA at bottom: "Get Started Free" etc.
```

**Hub page design rules:**
- Must look GOOD — not just for search engines, for users
- Styled panels, clean layout, nice background
- Categories give context to the keywords (Google reads this)
- Anchor text = the H1 of the target page (easy default)
- Link hub page from footer (under "Resources") AND/OR header nav

**Footer strategy:**
- Put most important BOFU pages directly in footer (1 click away = highest importance)
- Also link to hub page from footer
- Example: SociableKit puts top pages in footer + has full hub page

### Applied to Reviewly — Information Architecture Plan

**Footer:**
```
Product          Resources         Business Types
Pricing          Blog              Restaurants
Live Demo        FAQ               Dentists
Features                           Hotels
                                   Salons
                                   Auto Repair
```

**Hub page:** `/for/` — "AI Review Response Generator for Every Business Type"
- H1: "AI Review Responses for Your Business"
- Categories: Restaurants, Healthcare, Hospitality, Services
- Each links to /for/restaurants, /for/dentists, etc.
- CTA at bottom

**URL structure:**
```
/for/                          ← hub page (1 click from homepage via footer/nav)
/for/restaurants               ← BOFU landing page (2 clicks)
/for/dentists                  ← BOFU landing page (2 clicks)
/for/hotels                    ← BOFU landing page (2 clicks)
/for/salons                    ← BOFU landing page (2 clicks)
/for/auto-repair               ← BOFU landing page (2 clicks)
/for/property-managers          ← BOFU landing page (2 clicks)
```

**Also put top 3-4 business types directly in footer** (1 click = higher importance)

### Trust/Legitimacy Checklist for Reviewly
- [ ] Privacy policy page
- [ ] Terms of service page
- [ ] Contact page (or email in footer)
- [ ] Social profiles (LinkedIn, Twitter/X) linked in footer
- [ ] 3-5 short blog posts (written by human, link out to authority sites)
- [ ] Consistent branding across all pages
- [ ] Clean design with wide margins
- [ ] Connect Google Search Console
- [ ] Connect Bing Webmaster Tools
- [ ] Submit sitemap

---

## PART 6: Finding Keywords, High Leverage Keywords & When to Deprioritize

### The "It's Toasted" Principle (Finding More Keywords)
- Your product does things that EVERY competitor does — but nobody puts it in their SEO language
- List every feature, use case, detail about your product that someone might search
- Even obvious things: "free to use", "no signup required", "works on mobile"
- Amazon sellers do this — long titles covering every search variation
- Edward got his enterprise SEO job by listing every SEO skill on LinkedIn as keywords

**Applied to Reviewly:**
- "AI review response generator" ← obvious
- "Google review reply tool no signup" ← detail nobody else targets
- "review response generator with tone customization" ← feature-specific
- "respond to negative reviews in 10 seconds" ← benefit-specific
- "review reply tool for restaurants with custom instructions" ← ultra-specific

### High Leverage Keywords (Compact Keywords on Steroids)
These aren't just about one conversion — they target GROUPS, decision makers, or actions that amplify your brand:

**Types:**
1. **Plural/group keywords:** "for teams", "for schools", "for districts" — one conversion = hundreds of users
2. **Decision-maker keywords:** "for managers", "for directors", "for franchise owners"
3. **Embed/integration keywords:** Create embeddable features → target "embed [thing] on website" → users embed = backlinks to your site
4. **Guest writing/submission keywords:** "[industry] article submission" → influencers find you, write for you, share you
5. **Authority keywords:** Even just ranking for them makes your brand look legit to people who don't know SEO

**Priority:** High leverage keywords should be targeted FIRST because one ranking = exponential returns

### When to DEPRIORITIZE Keywords (The Filtering System)

**Skip (or delay) when you see:**

| Signal | What it means | Action |
|--------|---------------|--------|
| High DA (70+) dominating SERPs | Competitive, needs authority | Delay until DA 30+ |
| High page scores + high DA | Locked up tight | Skip or use YouTube video instead |
| SERPs full of "best of" lists | Intent is comparison, not purchase | Deprioritize |
| Top result is a how-to/definition | Intent may not be BOFU | Score as 3 (maybe), not 1 (yes) |
| Results unrelated to your niche | Too far from your category | Skip unless you can build relevance |
| Keyword results are "all over the place" | High volume but scattered intent | Low conversion despite volume |

**GO FOR IT when you see:**
- Low DA sites (teens/20s/30s) in SERPs
- Low/orange page optimization scores
- Nobody directly targeting the keyword in URL/title
- Clear purchase intent in the keyword language
- Related to your niche/product

### Edward's Relevance Scoring System
When doing keyword research, score each keyword:
- **1** = Perfect. Clear BOFU intent, low competition, directly related to brand → make page NOW
- **2** = Good. Might need slightly more DA or content → make page soon
- **3** = Maybe. Intent unclear OR somewhat competitive → make page later
- **4-5** = Deprioritize. Too competitive, wrong intent, or unrelated

### The "Misleading SERP" Insight
- Many SERPs show TOFU content because SEO writers only know TOFU style
- The search intent might actually be BOFU — nobody's made the right page yet
- If keyword SOUNDS like BOFU but SERP shows TOFU → opportunity to satisfy intent better
- Make a BOFU page, keep users from bouncing, Google will rank you higher over time

### YouTube Short as SERP Disruptor
- When a keyword has high DA sites but you can't compete with a page
- Make a YouTube Short targeting that same keyword
- Put keyword at beginning of title AND description
- Can rank on Google within HOURS
- Disrupts SERPs dominated by high DA websites

### Applied to Reviewly — Keyword Prioritization Framework

**Priority 1 (High leverage, easy, do first):**
- "AI review response generator for restaurants"
- "AI review response generator for dentists"
- "Google review reply tool for small business"
- "automated review response for hotels"
→ Specific, BOFU, low competition expected

**Priority 2 (Good, slightly broader):**
- "AI review response generator"
- "Google review response tool"
- "review reply generator"
→ Check SERPs first for DA/competition

**Priority 3 (Maybe, check intent):**
- "how to respond to Google reviews" (might be TOFU)
- "Google review response examples" (might be list/comparison)
→ Could go either way — check SERP, score accordingly

**Deprioritize:**
- "Google reviews" (way too broad)
- "reputation management software" (enterprise, high DA competitors)
- "review management" (scattered intent)

### For Moz Trial — The Exact Process
1. Enter seed keywords
2. Look at SERP analysis for each
3. Check DA of ranking sites (teens/20s = go, 70+ = skip)
4. Check page optimization scores (low/orange = opportunity)
5. Check if results are lists/how-tos (deprioritize) vs product pages (go)
6. Score each keyword 1-5 on relevance
7. Export everything to spreadsheet
8. Sort by score → build pages in order

---

## PART 7: Finding Competitors, Services/Local SEO & Low-Hanging Fruit

### Moz True Competitor Tool
- Enter your domain → shows list of competing websites
- Find competitors you didn't know about
- Then check what THEY rank for → find keywords they're not targeting properly → target those yourself
- Great for discovery phase during Moz trial

### Services/Local Business = Same Method
The compact keywords method works IDENTICALLY for:
- SaaS tools (Reverb, Bitrix24)
- Services businesses (Leeway Hertz, architecture firms, agencies)
- Local businesses (plumbers, electricians, dentists)
- Any business that solves problems people search for

**The key insight:** Find all the problems your business can solve. Each problem = a keyword. Each keyword = a BOFU landing page. Most competitors won't do this because they focus on TOFU.

### Leeway Hertz Pattern (Applied to Any Services Business)
Leeway Hertz is just a dev shop. But they create BOFU pages for:
- "Metaverse development company"
- "Generative AI development company"
- "AI debt collection"
- "mHealth app development"
- "Chatbot app development company"

Each page = same company, same service, different landing page tailored to specific search intent.

**For an architecture firm:** Every service they offer = a BOFU page
**For a plumber:** Every type of fix = a BOFU page + location modifier
**For Reviewly:** Every business type that gets Google reviews = a BOFU page

### Location Modifiers for Local SEO
- Take any service keyword → add city/neighborhood
- "NYC website migration SEO services"
- "Williamsburg Brooklyn plumber"
- Can clone the same page for multiple locations (if service is remote)
- Remove location = broader keyword, potentially another page

### Low-Hanging Fruit from Google Search Console (THIS IS GOLD)

**The process:**
1. Open Google Search Console → Performance
2. Look at keywords you're ALREADY ranking for
3. Filter for positions 6-25 (page 1 bottom + page 2)
4. These are LOW-HANGING FRUIT — you're close but not #1

**What to do with them:**

| Position | Action |
|----------|--------|
| 6-13 (page 1-ish) | Add keyword + extra sentences to EXISTING ranking page |
| 14-25 (page 2+) | Create a NEW dedicated BOFU landing page |
| Competitive keyword | Create dedicated page + link FROM existing ranking page |

**The Edward Method for growing rankings:**
1. Publish a BOFU page targeting a keyword
2. Wait a few months
3. Check Google Search Console — see what ELSE it's ranking for
4. For each new keyword found:
   - Either add it to the existing page
   - Or create a new dedicated page
5. Repeat → snowball effect

### Applied to Reviewly — Low-Hanging Fruit Strategy

**After launching SEO pages:**
1. Connect Google Search Console (priority #1)
2. Build initial BOFU pages (/for/restaurants, /for/dentists, etc.)
3. Wait 2-3 months
4. Check Search Console for surprise keywords we're ranking for
5. Create new pages for those keywords
6. Repeat — each page feeds more keywords

**Location variants to consider (Phase 2):**
- Don't need these for Reviewly initially (it's a national/global tool)
- BUT could target: "review response tool for restaurant owners" etc.

### Applied to ClaimArmor Pivot — Services Approach

The same "find all problems you can solve" method:
- "AI move out inspection report"
- "tenant damage documentation tool"
- "security deposit deduction letter generator"
- "rental property condition report app"
- "move in inspection report for landlords"
- "property damage report for insurance"

Each = a BOFU landing page with the SAME product but different framing.

Add location variants later:
- "move out inspection California"
- "security deposit documentation Texas"
- etc. (50 states = 50 pages via programmatic SEO)

### For Moz Trial — Additional Steps
1. Use **True Competitor** tool → find competitors for both Reviewly AND ClaimArmor pivot
2. Check competitor rankings → find keywords they rank for but don't target well
3. After initial pages are live, use Google Search Console to find low-hanging fruit
4. Create dedicated pages for keywords in positions 6-25

---

## PART 8: Live Keyword Research Demo (StageTimer.io Competitor)

### The Exact Step-by-Step Research Process

**Step 1: Export competitor keywords**
- Put competitor domain in Moz → export CSV
- Copy columns to Internal SEO template: keyword, volume, difficulty, rank, ranking page

**Step 2: Handle blank volume data**
- Blank volume ≠ worthless. Set ALL blanks to 1 (not zero)
- "Voice messaging for remote teams" had NO data — still brought entire organizations

**Step 3: Use ChatGPT for keyword brainstorming**
- Prompt: "I have a [product]. I'm doing bottom-of-funnel SEO. Give me keywords."
- Take suggestions → put into Moz SERP analysis → evaluate

**Step 4: Find keywords from SERP exploration**
- While researching one keyword, look at what competitors' page titles target
- Each competitor page title = potential new keyword to research

**Step 5: Evaluate each keyword**
1. DA of ranking sites — Low (teens/20s) = go. High (70+) = delay.
2. Page scores — Yellow/orange = wide open. Green = competitive.
3. Anyone targeting directly? — Keyword in URL + title? If NO = opportunity.
4. Intent clarity — Products or how-tos? Products = BOFU confirmed.
5. Relevance score 1-5.

### Edward's "Salivating" Signal
- Low DA + low page scores + nobody targeting directly + clear BOFU intent
- Example: "stopwatch for meetings" — DA 30, 19, 23. No pages optimized. WIDE OPEN.

### Niche-Down Strategy
- Competitor has broad page? Don't compete head-on.
- Make SPECIFIC pages: "yoga timer" instead of "gym timer"
- Less competitive, higher conversion, more targeted

### Same Product, Different Context
- StageTimer: "Create a timer" goes to SAME app from every page
- The product is identical — the landing page context changes
- Reviewly: same tool, but /for/restaurants frames it for restaurant owners

### For Moz Trial — Updated Process
1. Export competitor keywords → 2. ChatGPT seed brainstorm → 3. Moz SERP analysis per keyword → 4. Score each keyword → 5. Record in template → 6. Prioritize by DA+page scores+intent → 7. Niche-down broad keywords → 8. Save competitive ones for later

---

## PART 9: Live Keyword Research Demo #2 (Photo AI Competitor)

### The Full Research Workflow — Start to Finish

**Starting Point Options:**
1. Know a competitor? → Put their domain in Moz → see their rankings
2. Don't know competitors? → Start with a keyword you think people search → Keyword Suggestions → find who ranks → those are your competitors
3. No idea at all? → Ask ChatGPT: "I have [product description]. What are bottom-of-funnel keywords where people are searching for my use case but don't know the brand?"

**ChatGPT Prompt Template:**
"I have an app that [what it does]. What are some keywords I should go after where people are searching for my use case, but they don't know the brand that will satisfy their search intent?"
→ Use ChatGPT for STARTING POINTS, not final keyword list
→ Take each suggestion → put into Moz SERP analysis → evaluate yourself

### The Rabbit Hole Method
1. Start with ONE keyword or ONE competitor
2. See what they rank for → find 2-3 interesting keywords
3. Search those keywords → find NEW competitors in SERPs
4. Check what THOSE competitors rank for → find MORE keywords
5. Each keyword reveals more competitors, each competitor reveals more keywords
6. "Once you get the hang of it, it's effortless"

### Competitor Keyword Export Process (Detailed)
1. Put competitor domain in Moz → Keyword Explorer → click "Top Ranking Keywords"
2. Export CSV
3. Open CSV → copy columns: keyword, specific volume, difficulty, rank, ranking page, min volume, max volume
4. Paste into Internal SEO template (Paste Special → Values Only to preserve formatting)
5. Set all blank volumes to 1 (NOT zero)
6. Create a NEW tab for each competitor → color code each tab

### Evaluating Keywords — What Edward Looks For

**"I'm so hyped" keywords:**
- Example: "AI holiday photo" — nobody targeting directly, DA very low, clear BOFU intent
- Example: "AI photoshoot generator" — one competitor at DA 37, rest much lower, wide open

**One Page → Many Keywords strategy:**
- Find a cluster of related keywords (e.g., "AI Christmas photo", "AI family Christmas photo", "AI Christmas portrait generator")
- Create ONE page that incorporates variations naturally in the copy
- Don't keyword stuff — use variations to INFORM the copy (photo, photos, portrait, generator, make, create, family, couple, free)
- One well-written page can rank for dozens of related keywords

### Key Insight: Volume of 1 is Still Worth Targeting
- Volume 1 keywords can represent entire organizations
- If it's wide open and takes an afternoon → still worth it
- Pages add up. Traffic adds up. Conversions add up.
- Only deprioritize if you have higher-volume keywords that are EQUALLY open

### After Publishing: Track Keywords
- Use SEO software to track ranking position weekly for each targeted keyword
- Watch movement over time
- If climbing → page is satisfying intent
- If dropping → may need to improve page or re-evaluate keyword

### Applied to Reviewly — The Photo AI Method

**Step 1: Find competitors**
- Search "review response generator" in Moz → see who ranks
- Search "Google review reply tool" → see who ranks
- Check if reviewsyncai.com, reviewreply tools exist
- Export their keywords

**Step 2: ChatGPT brainstorm**
Prompt: "I have a SaaS tool where business owners paste their Google reviews and AI generates personalized, professional responses. What are bottom-of-funnel keywords where people are searching for this but don't know my brand?"

**Step 3: Go down the rabbit hole**
- Each competitor reveals more keywords
- Each keyword reveals more competitors
- Build the massive keyword list

**Step 4: One page → many keywords for each business type**
- /for/restaurants page → ranks for: "review response for restaurant", "restaurant review reply generator", "respond to restaurant reviews AI", "restaurant Google review template"
- Write copy that naturally includes: restaurant, review, response, reply, generate, AI, Google, professional, personalized

---

## PART 10: The Internal SEO Template — Keywords Tab Deep Dive

### Keywords Tab Columns Explained

| Column | What it is | How to use |
|--------|-----------|------------|
| Keyword | The BOFU keyword | List as you research |
| Category 1 | Hub page name (uses, alternatives, services) | For organization |
| Category 2 | Product line, modifier, or sub-category | Optional, changes as you learn more |
| Average Volume | Auto-calculated from min/max | Quick reference |
| Difficulty | Moz score | Edward IGNORES this — looks at SERPs himself |
| SERP CTR | Click-through rate estimate | Somewhat useful, usually ignored |
| Moz Priority | Combined score | Only used as tiebreaker |
| On-Site Relevance | YOUR score 1-10 | Most important column — lower = better |
| Notes | SERP observations | DA levels, page scores, intent, competition |
| Specific Monthly Volume | 12-month average from Moz | More accurate than min/max |
| Min/Max Volume | Range from Moz | Used for average calculation |
| Targeted | Yes/No — moved to page planning tab? | Green when yes |
| Published | Yes/No — is the page live? | Green when yes |

### Edward's Honest Assessment of Moz Metrics
- **Difficulty, SERP CTR, Priority → mostly IGNORED**
- **Average Volume + On-Site Relevance + SERP Notes → what actually matters**
- Only uses difficulty/priority as tiebreaker between two equally good keywords
- "I find it way more worthwhile to look at the keyword myself"

### Filtering Competitor Keywords — Remove Branded Terms
- When exporting competitor keywords, filter out their brand name
- Example: filter "Does not contain BITRI" (partial brand name catches most)
- What remains = non-branded keywords you could potentially rank for

### Two Methods for Getting Keyword Data

**Method 1: Manual (free)**
- Take each keyword → search in Moz Keyword Explorer → write data by hand
- Slower but works with any tool

**Method 2: Keyword List (Moz, ~$25 extra)**
- Take all keywords → paste into Moz Keyword Lists
- Export CSV → all data at once
- Use XLOOKUP to match data back to your spreadsheet if order differs

### XLOOKUP Process (When Data Order Doesn't Match)
1. Paste your keywords (in YOUR order) in column A of a helper sheet
2. Paste the Moz keyword list data (in THEIR order) next to it
3. Use =XLOOKUP(A2, $MozKeywords, $MozDataColumn) to match
4. Lock ranges with $ signs
5. Double-click corner to fill down
6. Drag across for each data column
7. Copy all → Paste Special Values Only into main template
8. Delete helper sheet

### Prioritizing When You Have 100+ Keywords
- Sort by On-Site Relevance (A→Z = best first)
- Filter by Category to focus on one hub page at a time
- Filter out already-targeted keywords (Targeted = Yes)
- Sort by Volume to find highest-traffic opportunities
- Filter by keyword to find related terms while topic is top of mind

### Key Insight: Categories Change Over Time
- Category 2 will change frequently as you learn more about your niche
- Don't over-think categories at the start — refine as keyword list grows
- The categories help when you have 100+ keywords and need to organize

### Applied to Reviewly — Moz Trial Template Setup

**Before starting the trial, prepare the template:**
1. Keywords tab ready with columns
2. Category 1 options: "for" (business types), "how" (FAQ/support), "vs" (alternatives)
3. Category 2 options: restaurants, dentists, hotels, salons, auto-repair, medical, property
4. On-Site Relevance scoring: 1 = perfect BOFU + directly relevant, 5 = maybe, 10 = skip

**During the trial:**
1. Export competitor keywords → filter out branded terms
2. Paste non-branded keywords into Keywords tab
3. Use Keyword List feature to bulk-get data ($25 extra — worth it for 7-day trial)
4. Score each keyword's on-site relevance
5. Add SERP notes for promising keywords
6. Sort and prioritize

---

## PART 11: Post-Page Checklist & Site SEO Layout Tab

### The Complete Post-Page Checklist (Before Submitting to Google)

1. **Check spelling/grammar** — paste into ChatGPT: "Tell me spelling, grammar, and other errors. Do not rewrite the whole thing."
2. **Check for AI detection** (if AI helped) — zerogpt.com, gptzero.me
3. **Check for plagiarism** — Copyscape
4. **Put page live** on site
5. **Test social sharing** — Meta Sharing Debugger (developers.facebook.com/tools/debug) → make sure OG image, title, description look correct
6. **Run Moz On-Page Grader** — aim for 96-98. Fix anything flagged.
7. **Submit to Google Search Console** — Inspect URL → Request Indexing
8. **Track keywords** in SEO tool — add keywords with labels (hub page names: uses, alternatives, services, branded)
9. **Mark as done** in Site SEO Layout tab

### Site SEO Layout Tab — Planning Page Skeletons

**Columns:**
- Keyword, Category 1 (hub page), Category 2, Hub page category, Product
- Content notes: words to fit in (required + optional)
- URL, Page Title, Meta Description
- OG Title, OG Description (only if different from page title — usually leave blank)
- H1, H2-1, H2-2, H2-3, H2-4 (first 4 sections — rest writes itself)
- Published: Yes/No

### The Page Planning Process

**Step 1: Identify words to fit in**
- From Moz Keyword Suggestions for your keyword
- From competitor landing pages (read their copy, steal useful words)
- Split into: required words vs optional words
- Write in Content Notes column

**Step 2: Write the URL**
- /[hub-page]/[keyword-slug]
- Example: manytimes.com/uses/stopwatch-for-meetings

**Step 3: Write page title**
- [Keyword] | [CTA/Benefit] | [Brand Name]
- Separated by vertical dividers
- Use capitalizemytitle.com for proper title case
- Example: "Stopwatch for Meetings | No Sign-Up Required | ManyTimes"

**Step 4: Write meta description**
- ChatGPT can HELP write meta descriptions (small enough, not risky)
- But edit for verbosity — remove unnecessary words
- Test with AI detection if ChatGPT helped
- Check length with totheweb.com SERP preview tool
- 120-158 characters

**Step 5: Write H1**
- Usually = the keyword (title case)
- Must sound natural, not forced/spammy

**Step 6: Plan first 4 H2s (sections)**
- Plan skeleton only — the rest writes itself
- H2s in sentence case (not title case)
- Each H2 = a different angle on the keyword
- Fit in your required/optional words across sections
- Example for "stopwatch for meetings":
  1. "Stopwatch for the meeting as a whole"
  2. "Countdown timer for individuals"
  3. "Online, free, and no sign-up required"
  4. "An intuitive asset for your presentation toolbox"

**Step 7: Write full copy in landing page template doc → move to CMS**

### Why Plan 5 Pages at a Time (Not 1 by 1)
- Find opportunities to hit multiple keywords with one page
- Avoid repetition across similar pages
- Better organize hub page categories
- Google likes organized, intentional site structure

### Keyword Tracking with Labels
- Track every keyword you target in your SEO tool
- Use labels matching hub pages: "uses", "alternatives", "services", "branded"
- Filter by label to see how entire hub pages perform
- Set region (National, or specific country)
- Weekly updates on ranking positions

### Applied to Reviewly — Site SEO Layout Setup

**Plan first 5 pages together:**
1. /for/restaurants — "AI Review Response Generator for Restaurants"
2. /for/dentists — "AI Review Response Generator for Dental Offices"
3. /for/hotels — "AI Review Response Generator for Hotels"
4. /for/salons — "AI Review Response Generator for Salons"
5. /for/auto-repair — "AI Review Response Generator for Auto Repair Shops"

**Words to fit across all pages (from keyword research):**
Required: review, response, reply, Google, AI, generate, professional, personalized
Optional: negative, positive, template, tool, software, free, business, owner

**Each page gets unique words too:**
- Restaurants: food, wait time, chef, menu, dining, service, waiter
- Dentists: patient, procedure, care, treatment, anxiety, dental
- Hotels: room, amenities, stay, location, hospitality, guest

---

## PART 12: Ranking Timelines & Troubleshooting When Pages Don't Rank

### Real Ranking Timelines (5 Keywords, 3 Sites)

| Keyword | DA | First Appeared | Time to #1 | Notes |
|---------|-----|----------------|-----------|-------|
| voice messaging for remote teams | 29 (was ~19-20) | Few weeks | Several months | Stayed #1 since, untouched |
| students record themselves reading | 29 | ~2 weeks (at #10) | ~2 months | Climbed 10→9→5→1. Gets entire districts. |
| NYC website migration SEO services | 34 | 1 week (at #25) | ~6 weeks | High ticket keyword. Dedicated page from GSC discovery. |
| growth hacking newsletter | 34 | Fast | Few weeks to #2, months to #1 | Had strong #1 competitor. Directory submissions helped. |
| [hidden keyword] | 14 | Many weeks | Several months | DA only 14! Page score 100 (should be 96). Still ranked #1. |
| [hidden high-volume keyword] | 14 | Many weeks | Several months | "One of my favorite keywords." Massive traffic. Untouched since. |

### What to Expect
- **Weeks 1-2:** May not appear at all
- **Weeks 2-4:** Start showing up (positions 10-25 typical)
- **Months 1-3:** Climb up and down, gradually trending higher
- **Month 3+:** Settle at #1-3 for non-competitive keywords
- **After #1:** Stays there for YEARS without updates
- Normal to bounce: #3 → #1 → #3 → #1 → stays at #1

### When Pages DON'T Rank — Troubleshooting Checklist

**1. Above-the-fold doesn't capture attention**
- First sentence doesn't use keyword or satisfy intent
- Image is irrelevant, AI-generated and obvious, or missing
- Not enough detail in intro
- Fix: Rewrite intro, add relevant image, make keyword prominent

**2. Page title isn't competitive enough**
- Just using the keyword = same as everyone else
- Fix: Add CTA or benefit after keyword: "Free | No Login | Use Now"
- Stand out in SERPs to get more clicks

**3. Over-optimization (score 100)**
- Google penalizes keyword stuffing / over-optimization
- Fix: De-optimize to 96-98. Remove keyword from alt text or vary it in first sentence.
- Edward has de-optimized pages and seen them rank BETTER

**4. Keyword fragment sounds awkward as H1/title**
- Don't force unnatural keywords
- Example: "students record themselves reading" → "Have Your Students Record Themselves Reading"
- Lower page score is OK if it sounds natural

**5. Spelling/grammar errors**
- Searchers bounce, Google notices
- Fix: ChatGPT prompt → "Tell me spelling, grammar, and other errors. Do not rewrite."

**6. Misjudged search intent**
- Thought it was BOFU but SERPs show mix of TOFU/MOFU
- Fix: Add brief TOFU sections (why, how, benefits) while keeping page primarily BOFU
- Add extra product angles (enhancer AND generator)
- Keep CTA prominent

**7. Needs more internal links**
- Link from hub page usually enough
- For important/competitive keywords: link from footer, other pages, blog posts
- Use natural anchor text (not always exact keyword)

**8. Technical issues (if ALL pages affected)**
- Pages set to noindex accidentally
- Robots.txt blocking crawler
- Staging site being indexed (duplicate)
- Orphan pages (not linked from anywhere)
- Site not crawlable
- Fix: Revisit technical SEO audit

**9. Just takes longer sometimes**
- Google adds random variance intentionally
- Edward had a page go from not ranking → #1 after MANY months with no changes
- Don't panic. Don't over-tweak.

### The Change Log (Critical Practice)
When modifying any page, record:
- Date of change
- What you changed
- Why you changed it
- What you hoped to fix
- Result (check after 2-4 weeks)

This prevents accidentally breaking what works and helps identify what actually moved the needle.

### Key Takeaway
Most BOFU pages will rank within 1-3 months for non-competitive keywords. If not ranking after 3+ months, work through the troubleshooting checklist above. Usually it's one of the first 4 issues.

---

## PART 13: Case Studies, Reddit SEO & App Store Optimization

### ColorBliss Case Study (DA 8 → 17, Ranking for 2,100+ Keywords)
- AI-generated coloring pages + programmatic SEO
- Was ranking for tons of keywords at DA 8 (EIGHT!)
- Pages are NOT well-optimized — keyword stuffing, un-QA'd content, broken AI images
- Still ranks #1 for hundreds of keywords because competition is SO LOW
- **Key insight: "The bar for what's necessary is so darn low"**
- If pages were properly optimized (score 96-98 instead of 87), would rank for even MORE high-volume keywords

### Dominic's $3M Win (Finance Company)
- 2 days of work: changed 3-5 pages to target BOFU keywords
- Put keyword in URL, title, meta, H1, first sentence
- Improved internal linking
- Result: $3M/year in additional revenue, still ranking years later
- Compact keywords can target massive purchase orders, not just individuals

### The Universal Rule for ALL Platforms
**"The closer your keyword is to the beginning of the first thing people read, the better optimized you are."**

This applies to:
- Google (page title, H1, first sentence)
- Reddit (post title, first sentence of comment)
- YouTube (video title, beginning of description)
- TikTok/Instagram (caption, beginning of description)
- App stores (app title, subtitle)
- Amazon (product title)
- LinkedIn (post beginning)
- ANY platform

### Two Things That Never Change
1. **Authority will always be valued** — backlinks for websites, upvotes for Reddit, followers for social, reviews for app stores
2. **Keyword at the beginning of what people read first** — this never changes regardless of platform

### Reddit & Parasite SEO (Edward's OBSERVATION, Not Recommendation)
- Reddit ranking for massive keywords ("best coffee" = #1)
- Black hat actors: AI-generated comments + bought upvotes + brand ambassador accounts
- Against Reddit's AND Google's terms of service
- Can result in: account bans, manual penalties, blacklisting
- **Edward explicitly does NOT recommend this — white hat only**
- But important to understand what's happening in the landscape

### Why Reddit Posts Rank
- Google is turbocharging Reddit in SERPs
- OpenAI training ChatGPT on Reddit data
- Engagement metrics (upvotes, comments) = authority signals
- Keyword in post title + first sentence = relevance signal
- BOFU keywords on Reddit = even easier to rank (low competition)

### App Store Optimization (ASO) = Bottom of Funnel by Nature
- Every app store search is BOFU — people want to USE something
- Same compact keywords principles apply:
  - Keyword at beginning of app title (before brand name)
  - Keywords in subtitle
  - Variations in description (not stuffing)
- Example: remove.bg puts "Background Remover" BEFORE brand name in title
- App store = another search engine to rank on

### Key Takeaway
You don't need high DA. You don't need perfect pages. ColorBliss proves that with DA 8 and un-QA'd AI content, you can still rank for hundreds of keywords. **The bar is low. If you do it RIGHT (which we will), you'll crush it.**

---

## PART 14: Video SEO — Ranking with YouTube Shorts, Reels & TikTok

### Why Video is Being Pushed by Google
- UGC (user-generated content) turbocharged in SERPs
- Reddit visibility skyrocketing since June 2023
- Video from YouTube, TikTok, Instagram being pulled into Google results
- Reason: AI-generated website content = disinformation. Video/comments = source of truth.

### Video SEO Advantages
1. Can rank on Google within HOURS (Edward: 8 hours → featured snippet)
2. Easy to make (free backlink checker video = few minutes)
3. Gets organic algorithmic reach (platforms push it for you)
4. Less competitive (many SEOs won't do video)
5. Comments = source of truth for Google
6. Builds brand while doing SEO
7. Unlimited tries — can target same keyword over and over

### Video SEO Disadvantages
- Volatile — might rank for days, months, or years
- Less durable than website BOFU pages (which rank for YEARS untouched)
- Need actual engagement — slop gets shadow banned

### How to Do Video SEO (The Exact Method)

**YouTube Shorts:**
1. Keyword at BEGINNING of title
2. Keyword at BEGINNING of first sentence in description
3. Use video transcript as rest of description (long descriptions help)
4. 1-3 hashtags only
5. Keyword in file name (best practice)

**Instagram Reels:**
1. No title field — only description
2. Keyword at BEGINNING of description
3. Use same description as YouTube

**TikTok:**
1. Keyword at BEGINNING of description
2. Same description works across all platforms

**Long YouTube Videos:**
1. Same rules: keyword at beginning of title + description
2. Write description yourself (transcript too long for long videos)
3. Put thought into description if actively targeting a keyword

### The Multi-Platform Strategy
- Make ONE video → post to YouTube Shorts, Instagram Reels, TikTok, Facebook Reels, Snapchat Spotlight
- Same description on all platforms
- Use Repurpose.io (reusevideo.com) to auto-post across platforms
- Each platform = its own search engine + feeds into Google

### Critical Rules
1. Video MUST be relevant to the keyword — can't just use engaging unrelated video
2. Searchers will watch, realize it's irrelevant, bounce → Google stops showing it
3. Videos need decent engagement — no engagement = shadow ban
4. Recency is prioritized — can keep posting new videos on same keyword
5. Best performing video wins — all variations tested against each other

### Video vs Website BOFU Pages
| Factor | Website Page | Video |
|--------|-------------|-------|
| Durability | Years (untouched) | Days to years (volatile) |
| Speed to rank | Weeks to months | Hours to days |
| Effort | Afternoon per page | Minutes per video |
| Duplicate targeting | NO (one page per keyword) | YES (unlimited videos per keyword) |
| Brand building | Indirect | Direct (face/brand exposure) |
| Reach | Only search | Search + algorithmic push |

### The Combined Strategy (Website + Video)
- Target same keyword with BOTH a website page AND videos
- Website page = durable, long-term ranking
- Videos = fast ranking, brand building, extra SERP coverage
- Edward's "maximize coverage" approach from earlier lesson

### Edward's Social Media Posting Guide
- edwardsturm.com/articles → "social media posting strategy"
- Free, constantly updated, step-by-step for every platform
- Covers: posting frequency, tools, keyword usage, platform-specific tips

### Applied to Reviewly — Video Strategy (Phase 2)
- After website BOFU pages are live, create short videos for same keywords
- Video idea: screen recording of Reviewly generating a response for a [restaurant/dentist/hotel] review
- 30-60 seconds, show the before (bad review) and after (professional response)
- Keyword at beginning of title + description
- Post to all platforms simultaneously
- Each video = another chance to rank + brand exposure

---

## PART 15: Linkable Assets — Creative Link Building

### What Are Linkable Assets?
Something cool, useful, or interesting on YOUR site that people naturally want to link to. Different from outreach-based link building — this ATTRACTS links.

### Types of Linkable Assets

**1. Valuable Data/Statistics Articles**
- Example: "57 New AI Statistics" by Exploding Topics
- 734 domains linking to it (Forbes, HubSpot, .edu sites)
- People cite your stats → link back to you
- Works because bloggers/journalists need data sources

**2. Viral Stunts**
- Example: "Score" dating app for people with 675+ credit score (Neon Money Club)
- 159 domains linking, including Financial Times, Fast Company, Mashable, Fortune
- Edward suspects they never actually BUILT the app — just announced it
- The announcement alone went viral and got massive links

**3. Micro SaaS Tools**
- Build a tiny, useful tool using AI coding tools (Cursor, Claude, Replit)
- Can be built in HOURS or DAYS, even by non-coders
- Examples: background remover (built in 20 min), Chrome extension, chatbot
- Launch on Product Hunt + BetaList for awareness + links
- KEY: If tool has share/embed function → users create backlinks FOR you
- Edward's example: Reverb's "embed audio in blog" → every embed = backlink

**4. Podcast on Your Domain**
- Edward's podcast page got followed link from Content Marketing Institute (DA 84)
- Without trying — just by having it on his domain
- Podcast directories also create links

**5. Newsletter on Your Domain**
- Newsletter landing page attracts links naturally
- Especially with conventional marketing/press

### Why Everything Lives on ONE Domain
- Podcast page → links go to your domain
- Newsletter page → links go to your domain
- Micro SaaS → links go to your domain
- All links compound on one domain = higher DA for everything

### Pro Tip: Buy Brandable Domains → 301 Redirect
- Buy catchy domain (compactkeywords.com, reusevideo.com)
- 301 redirect to your main site's page
- Links to the catchy domain pass SEO juice to your main domain
- Use catchy domain for marketing (easy to say in videos)

### Getting Awareness for Linkable Assets
1. **TikTok/Reels/Shorts** — quick videos about the asset (3 TikToks in 75 min → 67K views → 3,100 users in one day)
2. **Reddit** — share in relevant subreddit (Edward's fake celebrity video → #1 on all of Reddit → national TV)
3. **Pitch journalists** — use lucha.com for contact info, keep pitch SHORT, start with most interesting thing, personalize
4. **Product Hunt + BetaList** — for micro SaaS launches

### Applied to Reviewly — Linkable Asset Ideas
1. **Free "Review Response Examples" database** — searchable examples by business type + rating. Bloggers cite → link to us.
2. **"State of Google Reviews" report** — statistics on review response rates, impact on SEO. Data that journalists want to cite.
3. **Micro tools** — "Review Sentiment Analyzer" (paste review → get sentiment score). Free, lives on our domain, attracts links.
4. **Podcast/newsletter about local business marketing** — attracts links from marketing blogs

---

## PART 16: Podcast Link Building

### The Strategy: Go on Podcasts for Backlinks (+ Many Side Benefits)
- Edward: 30 podcasts in 3 months
- 70% from aipodcastmatcher.com (Podmatch)
- 20% from matchmaker.fm
- 10% from word of mouth

### Benefits Beyond Backlinks
1. Hosts recommend you to OTHER hosts (word of mouth chain)
2. Control the narrative — you write the description + choose which pages to link
3. Never-ending content to repurpose into short-form video
4. Hosts share you on social media (reshare for clout)
5. Makes your brand more searchable (images appear in Google)
6. Can direct links to SPECIFIC pages you want to build authority for

### The Tactical Link Approach
- Write the description YOURSELF, send it to host
- Include keywords naturally in the description
- Link to specific pages you're building authority for (not just homepage)
- Example: "Edward's bottom of funnel SEO program, Compact Keywords [link]"
- Each podcast = backlink with keyword-rich anchor text

### Podcast Matching Platforms

**aipodcastmatcher.com (Podmatch)** — $29-62/mo
- More hosts available
- 70% of Edward's appearances
- Fill out EVERYTHING in profile (helps matching algorithm)
- Include a video showing you're an engaging guest

**matchmaker.fm** — Free tier (10 messages/mo) or $15/mo
- Cheaper, still effective
- 20% of Edward's appearances
- Has filters to find niche-specific shows
- Can post content to attract hosts

### Messaging Hosts — What Works
- Simple: "Hey, you game?" (with strong profile backing it up)
- Longer: Brief flex of credentials + "I'd love to discuss [topic]"
- Always include: why you'd be a good guest + relevant experience
- NEVER pay a fee to be on a show — those are scams

### Profile Tips
- Fill out EVERYTHING
- Use all tags
- Flex credentials
- Record a video showing you're engaging
- Set your "send listeners to" link strategically (specific page, not just homepage)

### Key Insight: One Guy Got to DA 20 Just from Podcasts + LinkedIn
- Knew nothing about SEO or backlinks
- Just went on podcasts and posted on LinkedIn for a year
- Got to DA 20 — enough to rank for tons of compact keywords

### Applied to Reviewly/Sunny
- Could go on small business, marketing, or restaurant owner podcasts
- Each appearance = backlink + keyword-rich description
- Link to /for/restaurants or whatever BOFU page needs authority
- Description: "Reviewly is an AI review response generator for local businesses [link]"
- Free tier on matchmaker.fm = zero cost to start

---

## PART 17: Event Link Building (Take Over Meetup Groups)

### The Strategy: Take Over Abandoned Meetup Groups → Co-Host Events → Get Links

**How it works:**
1. Join tons of meetup groups in your niche in a big city
2. Wait for organizers to step down (happens constantly — they don't want to pay fees)
3. Take over as organizer (free, one click)
4. Rebrand with your name, links, descriptions, keywords
5. Find OTHER events in your niche (Eventbrite, Luma, Gary's Guide)
6. Offer to co-host: "I'll send my members to your event"
7. In return: get email list + your marketing blurb on their event pages
8. Links + awareness + email list growth — all without organizing events yourself

### Why This Works
- Organizers WANT attendees — they'll happily accept a co-host who sends people
- You inherit a built group (could be 1,000+ members built over years)
- Your marketing blurb appears on tons of event landing pages = backlinks
- Can be done from ANYWHERE (remote, outsourced to VA)
- Costs: only Meetup Standard fee (~$174/year)

### The Marketing Blurb (What Goes on Event Pages)
```
Co-hosted by the [City] [Niche] Meetup Group [meetup link]
Founded by [yourdomain.com]. [Brand] offers [keywords]. 
From [keyword 1] to [keyword 2], [domain] has everything.
```
- Appears on event landing pages, emails, social media posts
- Mix of do-follow and no-follow links
- Keywords in the blurb tell Google what your brand is about

### Rebrand the Taken-Over Group
- Name: [City] + [Niche] (e.g., "New York SEO", "Chicago Generative AI")
- Description: Keywords + links to pages you want to rank
- Photos: Brand images + keep existing event photos for credibility
- Links: Hub pages, BOFU landing pages, social profiles

### Edward's Biggest Win: Largest Blockchain Meetup in the World
- 10,000 members
- Ranked #1 on meetup.com/topics/blockchain
- Used to cold email anyone in blockchain: "I organize the biggest blockchain meetup in the world" → everyone said yes

### Key Insight: This is Outsourceable
- VA script: find events in niche → email organizer → offer co-hosting → send template blurb
- You never attend events
- You never organize events
- The existing organizers do all the work
- You just send members + collect links + collect emails

---

## PART 18: Expert Quotes, Press Releases & Press Kits

### Expert Quote Platforms (Free/Cheap Backlinks from High DA Sites)

**How it works:** Journalists need expert quotes → you answer → get published → get backlink

| Platform | Cost | Notes |
|----------|------|-------|
| Source of Sources (sourcesofsources.com) | Free | By HARO founder. 2-3 emails/day. Top publications. Strict rules. |
| Featured.com | Free tier + $39.80/mo paid | Edward: 79% acceptance rate on paid tier. Got Entrepreneur (DA 92) |
| Help a B2B Writer | Free | Tons of queries, HubSpot-level publications |
| Quoted | $99/mo | Less competition (price filters out people), platform works harder for you |
| matchmaker.fm | Free (10/mo) | For podcast appearances (covered in Part 16) |

### Writing Expert Answers That Get Accepted
- Start with WHY you're credible (credentials, companies, follower count)
- Short, punchy sentences. 1-3 sentence paragraphs.
- Sound CONFIDENT
- Give a HOOK in the first sentence
- Be specific with examples, not generic
- Include a link to a relevant page on your site
- Never use AI-generated answers
- Never BS or plagiarize

### Edward's Actual Results
- Entrepreneur Magazine (DA 92) — do-follow link from Featured.com
- Startup Nation (DA 59) — do-follow link
- Content Marketing Institute (DA 84) — do-follow link from podcast
- HubSpot articles via Help a B2B Writer
- 79% acceptance rate on Featured.com paid tier

### Strategic Language in Expert Quotes
- Use your description to inform Google what your site is about
- "Edward Sturm, SEO and marketing expert" → Google learns the site is about SEO/marketing
- Link to specific pages you want to build authority for (not just homepage)
- Include keywords naturally in your bio/description

### Press Releases
- Tool: PRLog.org ($615 for max syndication tier)
- Auto-syndicates to Yahoo Finance, Business Insider, smaller blogs
- Best when: hot niche + legitimately big news
- Headline = most important thing (big statement + brand name + niche signal)
- Mix of no-follow and do-follow links
- Only do 1-2 per year if budget allows
- If can't afford → skip, use free tools instead

### Press Kits
- For companies that might get journalist coverage
- Control the narrative — YOU choose the language next to your links
- Contents: brand logo (PNG), marketing blurb (1 paragraph + links), longer description, images
- Put in footer with anchor text "Press Kit"
- Can literally link to a Google Drive folder
- Language in press kit tells Google what your brand is about

### Applied to Reviewly
1. **Source of Sources + Help a B2B Writer** — answer queries about Google reviews, local SEO, small business marketing. Free.
2. **Featured.com free tier** — answer relevant queries, link to Reviewly
3. **Press kit** — create for footer: logo, blurb ("AI review response generator for local businesses"), screenshots
4. **Expert bio template:** "Reviewly is an AI-powered review response generator helping local businesses respond to every Google review professionally. [link]"

---

## PART 19: Link Building 101 — Directories, Launch Platforms & Fundamentals

### Backlink Fundamentals Recap
- Compact keywords DON'T need high DA to rank (ColorBliss ranked at DA 8)
- But backlinks help for competitive BOFU keywords
- Natural backlink profile = mix of high DA, low DA, dofollow, nofollow
- .edu and .gov links are especially valuable

### What Makes a Backlink Valuable (Hierarchy)
1. Site relevance (in your niche?)
2. Page relevance (about your topic?)
3. Section relevance (text around the link related?)
4. Anchor text relevance (keyword in the link text?)
5. Exact match anchor text = most valuable BUT too much = penalty
6. Natural mix: exact match + partial match + naked URLs + branded

### Directory Submissions (Easiest Link Building)
- Google "[your niche] directories" → submit to all free ones
- Use the directory template to track: login, email, password, description, topics
- Write LONG descriptions with keywords — tells Google what your site is about
- Descriptions inform language associated with your links

**Tools:**
- **boostbenchmark.com** ($67) — curated list of impactful directories, designed to get DA to 20
- **Semrush Local SEO tool** — submits to tons of directories in one click
- Manual: Google "[niche] directory" and submit yourself

### Edward's Directory Win
- Used Semrush Local → submitted to directories → dofollow backlinks
- "Keyword arbitration" ranking went from #8 → #1 right after directory submissions
- Directories → links to hub page → juice flows to BOFU pages nested inside

### Launch Platforms (Like Directories But With Engagement)
- **Product Hunt** (free) — biggest tech launch platform. Even Apple launches there.
- **BetaList** (paid) — good for tech products
- Launch every 3-6 months (especially with product updates)
- Fill out EVERYTHING on your listing (incomplete = hidden/not featured)
- The engagement from launches boosts SEO even beyond the backlink itself

**Edward's results:** Clear uptick in rankings every time he launches on Product Hunt. Tracked with Moz.

### General Philosophy: Build Brand → Links Follow
- Strong brands naturally acquire backlinks over time
- Name recognition compounds
- More links → rank for more keywords → more links (flywheel)
- Focus on long-term brand building, not risky tactics
- "Building like a Lego castle — one block at a time"

### Keep Everything on ONE Domain
- All products, services, podcast, newsletter → same domain
- Buy brandable domains → 301 redirect to your main site
- Rising tide lifts all boats — DA increase helps ALL pages rank better

### Applied to Reviewly
1. **Directories:** Google "SaaS directories", "AI tool directories", "small business tool directories" → submit Reviewly to all
2. **Launch:** Product Hunt launch when ready (fill out EVERYTHING)
3. **Semrush Local** (if budget allows) — one-click directory submissions
4. **Directory template:** Track all submissions for future language updates
5. **Link to hub page** (/for/) in directory listings — juice flows to all BOFU pages

---

## PART 20: The Complete Strategy Overview — "If I Was Designing Your SEO Strategy"

### The Full Compact Keywords Execution Order

**Phase 1: Defensive SEO (Audit)**
1. Use Screaming Frog + site audit template
2. Go through technical SEO lesson like a checklist
3. Fix all issues before doing anything offensive

**Phase 2: Keyword Research**
1. Look at competitor keywords
2. Use AI tools to bounce ideas
3. Look at SERPs for keyword gaps
4. Especially find HIGH LEVERAGE keywords (represent groups, clout, backlinks)
5. Write everything in Keywords tab

**Phase 3: Build Pages**
1. Set up 1-2 hub pages with nice design
2. Link hub pages from footer (or header if appropriate)
3. Churn out BOFU landing pages — one every day or every two days
4. For each page: keyword in URL, title (beginning), meta description (beginning), H1, first sentence
5. Add extra CTA/benefit in page title + brand name with dividers
6. Short punchy sentences, neutral tone, no sensationalism, no superlatives
7. Submit each to Google Search Console
8. Track all keywords

**Phase 4: Post-Build Audit**
1. Screaming Frog again — verify pages match what was planned in Site SEO Layout tab
2. Check for typos, wrong titles, wrong meta descriptions
3. Fix anything → resubmit to Search Console
4. 301 redirect any changed URLs

**Phase 5: Video SEO (Simultaneous)**
1. Make videos targeting same keywords as website pages
2. Keyword at beginning of title + description
3. Post on all platforms (YouTube Shorts, Reels, TikTok, etc.)
4. Follow edwardsturm.com social media posting strategy guide
5. Builds brand while reinforcing SEO

### Link Building Priority (Ranked by Effort/Time/Cost Balance)

| Priority | Strategy | Effort | Cost | Notes |
|----------|----------|--------|------|-------|
| #1 | Directories | Low | Free-$67 | Most straightforward. Use directory template. |
| #2 | Niche Launch Platforms | Low | Free-cheap | Product Hunt, BetaList. Always get a boost. |
| #3 | Expert Quotes | Medium | Free-$40/mo | Featured.com + Source of Sources. 1-2 submissions/day. |
| #4 | Event Link Building | Low (after setup) | ~$174/yr | Take over meetup, VA on autopilot. |
| #5 | Podcasts | Medium | $29-62/mo | aipodcastmatcher.com. Fun + links + content. |
| #6 | Viral Stunts / Micro SaaS | High (creative) | Varies | Not guaranteed but high potential. |
| #7 | Press Releases | Low effort | $615 each | 1-2/year if budget allows. PRLog.org. |

### Key Philosophy
- **Avoid ALL black hat tactics** — not necessary for compact keywords
- **No parasite SEO** — not worth the risk
- **Focus on durable brand + durable rankings**
- "You're probably not in gambling or pornography — the most competitive niches"
- Compact keywords don't need high DA to rank

### The Recap Checklist (One Page Summary)
1. ☐ Site audit (Screaming Frog + template)
2. ☐ Keyword research (competitors, ChatGPT, SERPs, rabbit holes)
3. ☐ Hub page(s) created + linked from footer
4. ☐ BOFU landing pages built (1 per day or every 2 days)
5. ☐ Each page: keyword in URL, title, meta, H1, first sentence
6. ☐ Each page submitted to Google Search Console
7. ☐ Keywords tracked in SEO tool
8. ☐ Post-build audit (verify pages match plan)
9. ☐ Video SEO on same keywords (simultaneous)
10. ☐ Directory submissions (#1 link building priority)
11. ☐ Launch platform submissions (Product Hunt, etc.)
12. ☐ Expert quotes (Featured.com, Source of Sources)
13. ☐ Event link building (meetup takeover + VA)
14. ☐ Podcasts (aipodcastmatcher.com)
15. ☐ Linkable assets / micro SaaS (when creative)
16. ☐ Press releases (1-2/year if budget allows)

---

## COURSE COMPLETE ✅

### Total Notes: 20 Parts, ~1000+ lines
### Saved at: research/compact-keywords-course-notes.md
### Ready for Moz trial execution
