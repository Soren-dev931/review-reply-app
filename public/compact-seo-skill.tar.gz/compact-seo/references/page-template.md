# BOFU Landing Page Template

## On-Page Optimization Checklist

1. Keyword in URL: `/uses/[keyword-slug]`
2. Keyword at beginning of page title: `[Keyword] | [CTA/Benefit] | [Brand]`
3. Keyword in meta description (near beginning), 120-158 characters
4. Keyword as H1 (exact match or natural variation)
5. Keyword at beginning of first sentence
6. Keyword in alt text of first image only (don't over-optimize)
7. Target Moz On-Page Score: 96-98 (NOT 100)

## Page Title Formula

```
[Keyword] | [Brand Name]
```
- Use vertical divider `|`
- Brand name at end
- Advanced: add CTA/benefit: `[Keyword] | Free, No Signup | [Brand]`

## Page Structure

```
[H1: Primary Keyword]

[2-3 punchy intro sentences — keyword near beginning of first]

[CTA Button]

[Hero image — BELOW CTA on mobile]

[H2: Section Title]
[1-3 sentences + bullet points]
[Image on right]
--- divider ---

[H2: Section Title]
[1-3 sentences + bullet points]
[Image on left]
--- divider ---

[H2: Section Title]
[1-3 sentences + bullet points]
[Image on right]
--- divider ---

[CTA Button again at bottom]
```

## Content Formula: Answer → Compare → Why Us

1. **Answer** — Directly answer the searcher's question. Factual, neutral, no fluff. Like a Google snippet.
2. **Compare** — Show what others charge or do. Give context. Let the reader see the market.
3. **Why Us** — Keyword-SPECIFIC differentiation. Not generic. This changes per page:
   - Cost page: "Others $1,250. We're $49."
   - Writing service page: "HR firms take 2-4 weeks. We do it in 10 minutes."
   - Generator page: "Canva designs them. We actually WRITE the content."

The answer earns the click. The comparison builds trust. The "why us" earns the conversion.

## Writing Rules

- ~415 words total (400-500 range)
- Short punchy sentences
- 1-sentence paragraphs (sometimes 2-3, usually 1)
- Heavy bullet points
- Neutral tone — converts better AND gets picked up by AI chatbots
- NO sensationalism ("deadly", "war zone", "crazy")
- NO superlatives ("best", "greatest", "#1")
- OK to emphasize: "free", "instant", "no signup required"
- 1 primary keyword + 1-2 secondary keywords MAX per page
- CTA at top AND bottom

## Section Layout

- Alternate: image right → image left → image right
- Dividing lines between sections
- No image for a section = center text (OK)
- Reuse images across BOFU pages (same product screenshots)
- Reuse entire sections below fold (FAQ, pricing, CTA, trust logos)

## Reusable Sections Strategy

- **80% unique content NEAR THE TOP** of the page
- Reusable sections go BELOW the fold
- Visitor must see unique/relevant content FIRST or they bounce
- Spread some unique content throughout for authenticity

## Image SEO

- File naming: `[subfolder]_[page-slug]_[image-description].webp`
- Alt text: first image = keyword, others = descriptive
- Reused images: re-upload with UNIQUE filename + alt text per page
- Format: WebP, compressed (TinyPNG)
- Only put keyword in alt text of FIRST image

## Handling Awkward Keywords

If keyword is clunky ("students record themselves reading"):
- H1/title: make natural: "Have Your Students Record Themselves Reading"
- URL slug can still be exact keyword
- Lower Moz score is OK — authenticity > score

## Planning Pages in Batches

Plan 5 pages at a time (not 1 by 1):
- Find opportunities to hit multiple keywords with one page
- Avoid repetition across similar pages
- Better organize hub page categories

## Hub Page Architecture

| Type | URL | Best For |
|------|-----|----------|
| Uses | /uses/ | Product companies (SaaS, tools) |
| For | /for/ | Audience-specific (business types, roles) |
| Alternatives | /alternatives/ | Competitor comparison pages |
| Services | /services/ | Services businesses |

Hub page structure:
```
H1: [Hub Title]
Intro: 1-2 sentences
Categories (H2s): Group by type
  → Links to individual BOFU pages (H1 as anchor text)
CTA at bottom
```
Styled panels, clean layout — not just HTML lists.
