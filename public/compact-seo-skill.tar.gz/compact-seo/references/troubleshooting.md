# Troubleshooting — When Pages Don't Rank

## Expected Ranking Timelines

| Timeframe | What to Expect |
|-----------|---------------|
| Weeks 1-2 | May not appear at all |
| Weeks 2-4 | Start showing up (positions 10-25 typical) |
| Months 1-3 | Climb up and down, gradually trending higher |
| Month 3+ | Settle at #1-3 for non-competitive keywords |
| After #1 | Stays for YEARS without updates |

Normal to bounce: #3 → #1 → #3 → #1 → stays at #1. Don't panic. Don't over-tweak.

## 9-Point Diagnostic Checklist

### 1. Above-the-fold doesn't capture attention
- First sentence doesn't use keyword or satisfy intent
- Image irrelevant, obviously AI-generated, or missing
- Not enough detail in intro
- **Fix:** Rewrite intro, add relevant image, make keyword prominent

### 2. Page title isn't competitive enough
- Just using the keyword = same as everyone else
- **Fix:** Add CTA or benefit: `[Keyword] | Free | No Login | [Brand]`
- Stand out in SERPs to get more clicks

### 3. Over-optimization (score 100)
- Google penalizes keyword stuffing
- **Fix:** De-optimize to 96-98. Remove keyword from alt text or vary in first sentence.
- Edward de-optimized from 100→98 and ranked BETTER

### 4. Awkward keyword as H1/title
- Forced unnatural keyword sounds spammy
- **Fix:** Make natural: "students record themselves reading" → "Have Your Students Record Themselves Reading"
- Lower page score is OK if it sounds natural

### 5. Spelling/grammar errors
- Searchers bounce, Google notices
- **Fix:** ChatGPT: "Tell me spelling, grammar, and other errors. Do not rewrite."

### 6. Misjudged search intent
- Thought BOFU but SERPs show TOFU/MOFU mix
- **Fix:** Add brief TOFU sections (why, how, benefits) while keeping page primarily BOFU
- Keep CTA prominent

### 7. Needs more internal links
- Hub page link usually enough
- For competitive keywords: link from footer, other pages, blog posts
- Use natural anchor text (not always exact keyword)

### 8. Technical issues (all pages affected)
- Pages set to noindex accidentally
- Robots.txt blocking crawler
- Staging site being indexed (duplicate content)
- Orphan pages (not linked from anywhere)
- **Fix:** Revisit technical SEO audit with Screaming Frog

### 9. Just takes longer sometimes
- Google adds random variance intentionally
- Edward had pages go from invisible → #1 after many months with zero changes
- **Don't panic. Don't over-tweak.**

## The Change Log (Critical Practice)

When modifying ANY page, record:
- Date of change
- What changed
- Why changed
- Expected result
- Actual result (check after 2-4 weeks)

Prevents accidentally breaking what works. Identifies what actually moved the needle.

## YouTube Shorts as SERP Disruptor

When a keyword has high DA sites you can't compete with on the web:
- Make a YouTube Short targeting that keyword
- Keyword at beginning of title + description
- Can rank on Google within HOURS
- Disrupts SERPs dominated by high DA websites
