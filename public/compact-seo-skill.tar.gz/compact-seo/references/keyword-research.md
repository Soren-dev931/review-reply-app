# Keyword Research — Full Process

## Starting Points

1. **Know a competitor?** Put their domain in Moz → see their rankings
2. **Don't know competitors?** Search a keyword → Keyword Suggestions → find who ranks → those are competitors
3. **No idea?** ChatGPT: "I have [product description]. What are bottom-of-funnel keywords where people are searching for my use case but don't know the brand?"

## The Rabbit Hole Method

1. Start with ONE keyword or ONE competitor
2. See what they rank for → find 2-3 interesting keywords
3. Search those keywords → find NEW competitors in SERPs
4. Check what THOSE competitors rank for → find MORE keywords
5. Each keyword reveals more competitors, each competitor reveals more keywords

## Competitor Keyword Export Process

1. Put competitor domain in Moz → Keyword Explorer → "Top Ranking Keywords"
2. Export CSV
3. Copy columns: keyword, volume, difficulty, rank, ranking page, min/max volume
4. Filter out branded terms (filter "Does not contain [BRAND]")
5. Set ALL blank volumes to 1 (NOT zero)
6. Create separate tab per competitor, color-coded

## Evaluating Each Keyword (SERP Analysis)

For each keyword, check:

| Signal | Go | Skip |
|--------|-----|------|
| DA of ranking sites | Teens/20s/30s | 70+ dominating |
| Page optimization scores | Yellow/orange (poorly optimized) | All green/high |
| Direct targeting | Nobody has keyword in URL+title | Multiple sites targeting directly |
| Intent | Product/tool pages in SERPs | "Best of" lists, how-tos |
| Relevance to product | Direct match | Tangential |

## Relevance Scoring

- **1** = Perfect BOFU intent, low competition, directly related → make page NOW
- **2** = Good, might need slightly more DA → make page soon
- **3** = Maybe, intent unclear or somewhat competitive → make page later
- **4-5** = Deprioritize — too competitive, wrong intent, or unrelated

## The "It's Toasted" Principle

List EVERY feature, use case, and detail someone might search. Even obvious things:
- "free to use", "no signup required", "works on mobile"
- Feature-specific: "with tone customization", "with custom instructions"
- Benefit-specific: "in 10 seconds", "without hiring HR"
- Audience-specific: "for small business", "for startups", "for teams"

## High Leverage Keywords (Prioritize First)

These target groups/decisions that amplify returns:
1. **Plural/group keywords:** "for teams", "for schools", "for districts" — one conversion = hundreds of users
2. **Decision-maker keywords:** "for managers", "for directors", "for franchise owners"
3. **Embed/integration keywords:** embeddable features → users embed = backlinks
4. **Authority keywords:** ranking for them makes brand look legit

## Tools

- **Moz Keyword Explorer** — SERP analysis, DA checks, keyword suggestions
- **MozBar extension** — see DA next to every search result in real-time
- **Moz On-Page Grader** — score competitor page optimization
- **Moz True Competitor** — discover unknown competitors
- **Semrush** — keyword data, competitor export, local SEO tool
- **Screaming Frog** (free up to 500 URLs) — technical SEO audit
- **ChatGPT** — seed keyword brainstorming (starting points only, not final list)

## Moz Trial Process (7-Day Sprint)

1. Have seed keyword lists ready before trial starts
2. Export competitor keywords → bulk keyword list ($25 extra, worth it)
3. SERP analysis on every promising keyword
4. Score all keywords in spreadsheet
5. Plan pages in Site SEO Layout tab
6. Export everything before trial ends
