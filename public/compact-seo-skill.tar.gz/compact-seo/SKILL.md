---
name: compact-seo
description: >
  Bottom-of-funnel (BOFU) SEO system for SaaS and small business sites. Covers keyword research,
  BOFU landing page creation (~415 words), hub page architecture, entity stacking, trust signals,
  link building, post-publish workflow, and Google Search Console low-hanging fruit optimization.
  Based on Edward Sturm's Compact Keywords method + Charles Float's entity-first launch framework.
  Use when: building SEO pages, planning keyword strategy, launching a new product's SEO,
  creating comparison/alternative pages, doing entity stacking, planning link building,
  or optimizing existing pages. Triggers on: "SEO pages", "BOFU pages", "keyword research",
  "compact keywords", "entity stacking", "link building", "hub pages", "alternatives pages",
  "competitor comparison pages", "SEO launch", "SEO strategy", "landing pages for SEO".
---

# Compact SEO — Bottom-of-Funnel SEO System

## Core Principle

Target BOFU keywords where the searcher KNOWS what they want but doesn't know the brand. These convert 5-15% vs 0.5% for TOFU. Less competitive, less work, rank for YEARS untouched, AI-resistant (chatbots recommend BOFU pages).

## Launch Order (Always Follow This Sequence)

### 1. Entity First (Before Any Content)
Make Google understand what the brand IS:
- Social profiles on every major platform (X, LinkedIn, FB, Instagram, YouTube) — post something
- List in every free relevant directory
- Competitor backlink mining: `"competitor name" -site:competitor.com` → find their directories → get listed
- `sameAs` schema linking all social profiles on the site
- Product Hunt + beta lists for tech launches
- Footer: all social links + privacy/terms/contact

### 2. Trust Signals
Site must look like a real company. Pogo sticking = death to rankings:
- Privacy policy, terms of service, contact page
- Social profiles linked in footer
- Wide margins, clean design, real branding
- Short blog (human-written, link out to authority sites — sites that link OUT rank higher)
- Consistent NAP (Name, Address, Phone) across all directories

### 3. Keyword Research
See `references/keyword-research.md` for the full process. Summary:
- Export competitor keywords → filter branded → seed brainstorm → SERP analysis per keyword
- Check DA of ranking sites (teens/20s = go, 70+ = skip) + page optimization scores
- Score relevance 1-10. Blank volume = 1 (not 0). "No data" keywords can represent entire organizations.
- Rabbit hole method: each keyword reveals competitors, each competitor reveals keywords

### 4. Build Pages
See `references/page-template.md` for the exact page structure. Summary:
- ~415 words per page. Keyword in URL, title (beginning), meta description (beginning), H1, first sentence
- Score 96-98 on Moz On-Page Grader (NOT 100 — over-optimization hurts)
- Content formula: Answer → Compare → Why Us (each "Why Us" is keyword-specific, not generic)
- Neutral tone, short punchy sentences, 1-sentence paragraphs, bullet points, no superlatives
- CTA at top + bottom. Alternating image left/right sections with dividers
- 80% unique content near top, reusable sections (FAQ, pricing, CTA) below

### 5. Hub Pages & Information Architecture
- Hub pages: `/uses/`, `/for/`, `/alternatives/`, `/services/`
- BOFU pages must be ≤2 clicks from homepage
- Hub pages linked from footer AND/OR header nav
- Hub pages must look good (styled panels, categories, not just HTML lists)
- Top 3-4 BOFU pages also directly in footer (1 click = highest importance)
- Anchor text on hub page = H1 of target page

### 6. Post-Publish Workflow
For each page:
1. Grammar check (ChatGPT: "Tell me errors. Do not rewrite.")
2. Moz On-Page Grader → aim 96-98
3. Meta Sharing Debugger (Facebook tools) → verify OG image/title/description
4. Submit to Google Search Console (Inspect URL → Request Indexing)
5. Also submit to Bing Webmaster Tools (improves ChatGPT/SearchGPT recommendations)
6. Track keywords in SEO tool with hub-page labels
7. Mark done. Keep a change log for every modification.

### 7. Low-Hanging Fruit (Ongoing, After 2-3 Months)
Google Search Console → Performance → keywords ranking 6-25:
- Positions 6-13: add keyword + extra sentences to EXISTING ranking page
- Positions 14-25: create NEW dedicated BOFU page
- Repeat quarterly — each page feeds more keywords (snowball effect)

## Entity Stacking Checklist

Execute this for EVERY new product launch:

**Socials (create + post at least once):**
- [ ] Facebook page
- [ ] X (Twitter) account
- [ ] Instagram account
- [ ] LinkedIn company page
- [ ] YouTube channel

**Directories:**
- [ ] G2
- [ ] Capterra / GetApp / Software Advice
- [ ] Crunchbase
- [ ] SaaSHub
- [ ] Trustpilot
- [ ] Product Hunt (when account age allows)
- [ ] AlternativeTo (when account age allows)
- [ ] Google `"competitor" -site:competitor.com` → submit to every directory they're in

**On-Site:**
- [ ] `sameAs` schema in site head/layout linking all social profiles
- [ ] Social icons in footer linking to all profiles
- [ ] Privacy policy page
- [ ] Terms of service page
- [ ] Contact page (at minimum: email)

## When to Skip a Keyword

- High DA (70+) dominating SERPs with well-optimized pages
- SERPs full of "best of" comparison lists
- Top result is how-to/definition (intent may not be BOFU)
- Results unrelated to your niche

## When to GO for a Keyword

- Low DA sites (teens/20s/30s) in SERPs
- Low/orange page optimization scores
- Nobody targeting the keyword directly in URL/title
- Clear purchase intent in keyword language

## Link Building Priority

1. **Directories** — easiest, most straightforward
2. **Launch platforms** — Product Hunt, BetaList (launch every 3-6 months with updates)
3. **Expert quotes** — Source of Sources (free), Featured.com, Help a B2B Writer
4. **Event link building** — take over abandoned meetup groups, co-host for links
5. **Podcasts** — aipodcastmatcher.com, matchmaker.fm
6. **Linkable assets / micro SaaS** — build tiny tools that attract natural links
7. **Press releases** — PRLog.org, 1-2/year if budget allows

## Video SEO (Simultaneous with Pages)

Target same keywords with YouTube Shorts/Reels/TikTok:
- Keyword at BEGINNING of title + description
- Transcript as description for Shorts
- Can rank on Google within HOURS
- Can target same keyword unlimited times (unlike website pages)
- Post to all platforms (YouTube, Instagram, TikTok, Facebook, Snapchat)

## Reference Files

- `references/keyword-research.md` — Full keyword research process, scoring, rabbit hole method, competitor analysis
- `references/page-template.md` — Exact BOFU page structure, writing rules, section layout, image SEO
- `references/troubleshooting.md` — When pages don't rank: 9-point diagnostic checklist + ranking timelines
- `references/course-notes.md` — Complete Edward Sturm course notes (20 parts) — use for deep reference
